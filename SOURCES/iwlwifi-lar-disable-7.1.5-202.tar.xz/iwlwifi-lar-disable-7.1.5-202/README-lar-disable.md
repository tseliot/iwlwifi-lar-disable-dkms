# iwlwifi lar_disable DKMS test

This experimental build adds `iwlwifi.lar_disable=1`. When enabled at module
load, it suppresses the BIOS LARI regulatory configuration command sent to
firmware. It is broader than the old removed parameter and must be used only
as a diagnostic on hardware where local 6 GHz operation is permitted.
